import java.util.ArrayList;

public class Controller {
    private Display display;
    private Square[] squares;
    private Player[] players;
    private boolean status;

    public Controller(Display display, Square[] squares, Player[] players) {
        this.display = display;
        this.squares = squares;
        this.players = players;
    }

    public Square[] getSquares() {
        return squares;
    }

    public void setSquares(Square[] squares) {
        this.squares = squares;
    }

    public Player[] getPlayers() {
        return players;
    }

    public void setPlayers(Player[] players) {
        this.players = players;
    }

    public Display getDisplay() {
        return display;
    }

    public void setDisplay(Display display) {
        this.display = display;
    }

    public int[] rollDice(){

    }

    public void movement() {

    }

    public int[] checkSquareTyoe() {

    }

    public int[] checkProperty() {

    }

    public boolean confirmPurchase() {

    }

    public int[] purchaseProperty(Player owner, Property property) {

    }

    public int[] payRent(Player renter, Player landlord, Property property) {

    }

    public int[] retirement() {

    }

    public int[] chance() {

    }

    public int[] go() {

    }

    public int[] tax() {

    }

    public int[] jail() {

    }

    public int[] leaveJail() {

    }

    public int[] checkGameStatus() {

    }

    public int[] winSequence() {

    }
}
