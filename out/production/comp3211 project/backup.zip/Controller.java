import java.util.ArrayList;
import java.util.Random;

public class Controller {
    private Display display;
    private Square[] squaresList;
    private Player[] playersList;
    private boolean status;
    private int lastPlayer;
    private int turns;
    private String userInput;

    public Controller(Display display, Square[] squares, Player[] players) {
        this.display = display;
        this.squaresList = squares;
        this.playersList = players;
        turns = 0;
        lastPlayer = 0;
    }

    public void play(Display display, Square[] squaresList, Player[] playersList, Boolean status, int turns, String userInput){
        // Responsible to process user input, update game state, check the game status, call the Display to show lines to users.
    }

    // roll a dice and return the num
    public int rollDice() {
        Random random = new Random();
        return random.nextInt(3) + 1;
    }

    public void movement(Player player) {
        int squaresToMove = player.getPlayerPosition() + rollDice() + rollDice();
        player.setPlayerPosition(squaresToMove);
    }

    /*PROPERTY(0),
    CHANCE(1),
    GO(2),
    TAX(3),
    PARKING(4),
    TOJAIL(5),
    JAIL(6);*/
    // return the square type
    public int checkSquareType(Square square) {
        return square.getSquareType().ordinal();
    }

    // check who owns the property and do the follow up
    public void checkProperty(Player player, Property property, Player[] playersList) {
        Boolean propertyOwned = property.isOwned();
        // pay rent to landlord
        if (propertyOwned) {
            payRent(player, findPropertyOwner(playersList, property), property);
        } else {
            // Call Display to ask the player buy or not

            if (confirmPurchase(userInput)) {
                purchaseProperty(player, property);
            }
        }
    }

    public Player findPropertyOwner(Player[] playersList, Property property) {
        Player owner = null;
        for (int i = 0; i < playersList.length; i++) {
            if (property.getOwner().equals(playersList[i].getPlayerName())) {
                owner = playersList[i];
            }
        }
        return owner;
    }

    public boolean confirmPurchase(String answer) {
        if (answer.equals("Yes")) {
            return true;
        }
        if (answer.equals("No")) {
            return false;
        } else {
            // TODO  do the exception handling
            return true;
        }
    }

    public boolean saveGame(String location) { return false; }

    public boolean loadGame(String location) { return false; }

    public int[] payRent(Player renter, Player landlord, Property property) { return null; }

    public void purchaseProperty(Player buyer, Property property) { }

    public int[] retirement() { return null; }

    public boolean enoughMoney() { return true; }

    public boolean isBankrupt() { return false;}

    public void updateTurnNumber(int turns) { }

    //perform operation chance
    public String chance(Player player) { return null; }

    //perform operation go
    public String go(Player player) { return null; }

    //perform operation income tax
    public String incomeTax(Player player) { return null; }

    // Move player to jail
    public void jail(Player player) {
        player.setPlayerPosition(5);
        player.setStatus("jail");
    }

    public int[] leaveJail() {
        return null;
    }

    public int[] checkGameStatus() {
        return null;
    }

    public int[] winSequence() {
        return null;
    }

    public Square[] getSquaresList() {
        return squaresList;
    }

    public Player[] getPlayersList() {
        return playersList;
    }

    public void setDisplay(Display display) {
        this.display = display;
    }
}
