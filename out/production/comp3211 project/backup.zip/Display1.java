public class Display {
    public void displayBoard(Square[] squares, Player[] players) {}

    public void printPlayerInfo(Player player) {}

    public void displayWinMsg(Player player) {}

    public String acceptInput(Player player, String inputMsg) { return "";}

    public void printMsg(String string) {}
}
